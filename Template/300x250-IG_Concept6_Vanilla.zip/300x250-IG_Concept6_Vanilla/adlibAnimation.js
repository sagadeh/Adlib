
// default initial values before the animation kicks in
gsap.set("#main", { display: "none" });
gsap.set(["#container", "#sub-logo", "#lastframe-cta-wrapper"], {opacity: 0});
gsap.set("#bgimage-wrapper", {perspective: "1000px"});
gsap.set("#bgImage", {scale: 1.1});
gsap.set(["#headline1-bg", "#headline2-bg", "#headline3-bg", "#extralegal-bg"], {scale: 0});
gsap.set(["#headline1-wrapper", "#headline2-wrapper", "#headline3-wrapper", "#disc-wrapper", "#extralegal-wrapper"], {opacity: 0, y: 20});
gsap.set("#cta-wrapper", {x: -20, opacity: 0});


gsap.globalTimeline.pause();

function initAnim() {
	templateCSS(defaultValues.cssAttrib); 
	adlibStart();
	setTimeout(deployAnimation, 1000);
}

function deployAnimation() {
	console.log("animation initialized")
	initOptionBSettings();
	
	document.querySelector("#taparea").addEventListener("click", function () {
		Enabler.exitOverride("Your Exit Name here", defaultValues.landingPage);
	});

	gsap.globalTimeline.resume();

	// animation start here after global resume.
	gsap.set("#main", { display: "block", onComplete:txtResizer});

	function frame1Animation() {
		gsap.to("#container", {duration: 1, ease: "quad.inOut", opacity: 1});
		gsap.to("#bgImage", {duration: 12, ease: "power1.inOut", scale: 1, rotationZ: 0.01});
		gsap.to("#red-BG", {duration: 0.8, ease: "quad.inOut", height:"100%", delay: 0.5});
		gsap.to("#headline1-bg", {duration: 0.5, ease: "quad.inOut", scale: 1, delay: 0.8});
		gsap.to("#headline1-wrapper", {duration: 0.3, ease: "quad.inOut", opacity: 1, y: 0, delay: 1.3, onComplete:
			function(){
				takeScreenshot();
				gsap.delayedCall(2, frame2Animation);
			}
		});
	}

	function frame2Animation() {
		gsap.to("#headline2-bg", {duration: 0.5, ease: "quad.inOut", scale: 1});
		gsap.to("#headline2-wrapper", {duration: 0.3, ease: "quad.inOut", opacity: 1, y: 0, delay: 0.5, onComplete:
			function(){
				takeScreenshot();
				if(defaultValues.frame3Headline.length <= 1){
					gsap.set("#headline2-wrapper",{top:"130px"});
					gsap.set("#disclaimerText",{color:"#fff"});
					gsap.delayedCall(0.2, initCTAandRW);
				}else{
					gsap.delayedCall(2, frame3Animation);
				}
				
			}
		});
		if(defaultValues.animationType != "Option B")
			return;
		gsap.to("#headline1-wrapper", {duration: 0.5, ease: "quad.inOut", y: -132});			

	}

	function frame3Animation() {
		gsap.to("#headline3-bg", {duration: 0.5, ease: "quad.inOut", scale: 1});
		gsap.to("#headline3-wrapper", {duration: 0.3, ease: "quad.inOut", opacity: 1, y: 0, delay: 0.5, onComplete:
			function(){
				takeScreenshot();
				gsap.delayedCall(0.2, initCTAandRW);
			}
		});
	}

	function initCTAandRW() {
		gsap.to("#cta-wrapper", {duration: 0.5, ease: "quad.inOut", opacity: 1, x: 0});
		gsap.to("#disc-wrapper", {duration: 0.5, ease: "quad.inOut", opacity: 1, y: 0, delay: 0.3, onComplete:
			function(){
				takeScreenshot();
				if(defaultValues.legal.length <= 1){
					gsap.delayedCall(2, endFrameAnim);
				}else{
					gsap.delayedCall(2, extraLegalAnim);
				}
				
				
			}
		});
	}

	function extraLegalAnim() {
		gsap.to("#extralegal-bg", {duration: 0.5, ease: "quad.inOut", scale: 1});
		gsap.to("#extralegal-wrapper", {duration: 0.5, ease: "quad.inOut", opacity: 1, y: 0, delay: 0.5, onComplete:
			function(){
				takeScreenshot();
				gsap.delayedCall(2, endFrameAnim);
			}
		});
	}

	function endFrameAnim() {
		takeScreenshot();
		adlibEnd();
		if(defaultValues.trigger != "enable endframe")
			return;
		gsap.to("#brand-logo", {duration: 0.5, ease: "quad.inOut", opacity: 0});
		gsap.to("#red-BG", {duration: 1, ease: "quad.inOut", width: "100%", delay: 0.3});
		gsap.to("#sub-logo", {duration: 0.5, ease: "quad.inOut", opacity: 1, delay: 0.8});
		gsap.to("#lastframe-cta-wrapper", {duration: 0.5, ease: "quad.inOut", opacity: 1, delay: 0.8, onComplete: adlibEnd});
		

	}
	
	frame1Animation();
}

function txtResizer() {
	autoFontSize("headline1-wrapper", "headline1", 21, 8);
	autoFontSize("headline2-wrapper", "headline2", 21, 8);
	autoFontSize("headline3-wrapper", "headline3", 21, 8);
	autoFontSize("disc-wrapper", "disclaimerText", 10, 6);
	autoFontSize("extralegal-wrapper", "legalText", 10, 6);

	
}

function initOptionBSettings() {
	if(defaultValues.animationType == "Option B"){
		gsap.set(["#headline1-bg", "#headline3-bg"], {height:"250px"});
		gsap.set("#headline3-wrapper", {top: "27px", height:"146px"});
	}
}



gsap.ticker.fps(30);