"use strict";


var defaultValues = {
  cssAttrib:"<! –– css styling if necessary ––>",
  frame1Headline:"SAVE & SAVE<br>AGAIN WITH<br>ENERGIA",
  frame2Headline:"SAVE £30<br>IN ATTIC<br>INSULATION<br>& REDUCE<br>YOUR BILLS<br>BY 30%",
  frame3Headline:"& GET IRELANDS’<br>CHEAPPEST DUAL<br>FUEL BUNDLE<br>THIS SUMMER",
  baseImage:"background.png",
  ctaText:"GET THIS PLAN",
  landingPage:"https://google.com"
  
};

function initDynamic() {
    if (!Enabler.isServingInLiveEnvironment()) {
    	defaultValues.frame1Headline;
    	defaultValues.frame2Headline;
    	defaultValues.frame3Headline;
    	defaultValues.baseImage;
    	defaultValues.ctaText;
    	defaultValues.landingPage;

    } else {
      
    }
}


function loadDefaultValues() {
	document.querySelector("#fr1-txt").innerHTML = defaultValues.frame1Headline;
	document.querySelector("#fr2-txt").innerHTML = defaultValues.frame2Headline;
	document.querySelector("#fr3-txt").innerHTML = defaultValues.frame3Headline;
	document.querySelector("#ctaTxt").innerHTML = defaultValues.ctaText;
	document.querySelector("#background-img").setAttribute("source", defaultValues.baseImage);
	document.querySelector("#background").setAttribute("source", defaultValues.baseImage);
	document.querySelector("#background_2").setAttribute("source", defaultValues.baseImage);
	document.querySelector("#background_3").setAttribute("source", defaultValues.baseImage);
}