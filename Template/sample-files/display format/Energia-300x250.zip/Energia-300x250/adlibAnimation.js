"use strict";


gsap.set("#fr1-txt-ctn", {width: 0});
gsap.set("#fr2-txt-ctn", {opacity: 0});
gsap.set("#fr3-txt-ctn", {opacity: 0, width: 0});
gsap.set("#coin-1", {x: 0, y: 288});
gsap.set("#coin-2", {x: 580, y: 288});
gsap.set("#ctaTxt", {scale: 0});


gsap.globalTimeline.pause();


//call play pause
function callGWDPlayPause() {
	console.log("callGWDPlayPause");
	gwd.auto_PauseBtnClick = function (event) {
		gsap.globalTimeline.pause(); 
		try{_video.pause();}catch(e){}
		console.log("Pause Timeline");
	};
	gwd.auto_PlayBtnClick = function (event) {
		gsap.globalTimeline.resume(); 
		try{_video.play();}catch(e){}
		console.log("Play Timeline");
	};

}


function initAnim(){
	loadDefaultValues();
	adlibStart();
	callGWDPlayPause();
	setTimeout(frame1Anim, 500);
}

function frame1Anim(){
	gsap.globalTimeline.resume();
	gsap.to("#coin-1", {duration: 3, ease: "power1.out", x: 580, onComplete: function(){
		gsap.set("#fr2-txt-ctn", {opacity: 1});
		gsap.delayedCall(1.4, frame2Anim);

	}});
	gsap.to("#coin-base", {duration: 3, ease: "power1.out", rotationZ: 180});
	gsap.to("#fr1-txt-ctn", {duration: 2, ease: "power1.out", width: 234, delay: .3, onComplete:takeScreenshot});	

}

function frame2Anim(){
	gsap.to("#coin-2", {duration: 3, ease: "power1.out", x: 0, onComplete: function(){
		gsap.set("#fr3-txt-ctn", {opacity: 1, width: 0});
		gsap.set("#coin-1", {x: 0});
		gsap.set("#coin-base", {rotationZ: 0});
		gsap.delayedCall(1.4, frame3Anim);

	}});
	gsap.to("#coin-base2", {duration: 3, ease: "power1.out", rotationZ: -180});
	gsap.to("#fr1-txt-ctn", {duration: 2, ease: "power1.out", width: 0, delay: .3, onComplete:takeScreenshot});
}


function frame3Anim(){
	gsap.to("#coin-1", {duration: 3, ease: "power1.out", x: 580, onComplete: function(){
		showCTA();
	}});

	gsap.to("#coin-base", {duration: 3, ease: "power1.out", rotationZ: 180});
	gsap.to("#fr3-txt-ctn", {duration: 2, ease: "power1.out", width: 234, delay: .28, onComplete:takeScreenshot});
	
}

function showCTA(){
	gsap.to("#fr3-txt-ctn", {duration: 0.3, ease: "power2.out", y: -16});

	var tl = gsap.timeline({delay: 0.2});

	tl.to("#ctaTxt", {scale: 1.04, duration: 0.4, ease: "power1.inOut"})
  	  .to("#ctaTxt", {scale: 0.90, duration: 0.4, ease: "power1.inOut"})
      .to("#ctaTxt", {scale: 1, duration: 0.4, ease: "power1.inOut"})
       .to("#ctaTxt", {scale: 0.90, duration: 0.4, ease: "power1.inOut"})
      .to("#ctaTxt", {scale: 1, duration: 0.4, ease: "power1.inOut", onComplete:adlibEnd});

}