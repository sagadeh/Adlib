"use strict";

var headline1 = document.getElementById('headline1');
var subHeadline1 = document.getElementById('author');
var headline2 = document.getElementById('headline2');
var headline3 = document.getElementById('headline3');

var img1 = document.getElementById('image1');
var img2 = document.getElementById('image2');
var ctaTxt = document.getElementById('cta');
var splitExit = false;
var data = {};

function initDynamic() {
	console.log("initDynamic");
 // Dynamic Content variables and sample values

    // Dynamic Content variables and sample values
   // Dynamic Content variables and sample values
    // Dynamic Content variables and sample values
    Enabler.setProfileId(10355700);
    var devDynamicContent = {};

    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge= [{}];
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0]._id = 0;
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].ID = 1;
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Reporting_Label = "bd4da61b0ba84809a438813fb930df35-5608-fe2304b1a82fd0fe3b20d8f3db1e933735e0bb25";
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Active = true;
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Weights = 1;
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].isDefault = false;
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].KEYWORDS = "prospecting";
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].ReadableLabel = "v6_Week3_BrightEyes_300x600";
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Targeting = [237701763];
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].CreativeDimension = [];
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].CreativeDimension[0] = {"Width": 300, "Height": 600};
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Headline1 = "\"By Week 3, my Mia\'s eyes were brighter.\"";
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Subheadline2 = "- Lydia";
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Headline2 = "Only 1 week to notice Jasper's higher energy levels";
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Headline3 = "Ready to start the Purina 3 Week Challenge?";
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].CTA = "BUY NOW";
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].FilterableLabel = ["v6_Week3_BrightEyes_300x600"];
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Image1 = {};
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Image1.Type = "file";
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Image1.Url = "https://s0.2mdn.net/ads/richmedia/studio/60001657/60001657_20190108022128261_300x600_BrightEyes_Image1.jpg";
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Image2 = {};
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Image2.Type = "file";
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Image2.Url = "https://s0.2mdn.net/ads/richmedia/studio/60001657/60001657_20190108022134283_300x600_BrightEyes_Image2.jpg";
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Url1 = {};
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Url1.Url = "https://www.tesco.ie/groceries/product/search/default.aspx?searchBox=Purina%20ONE";
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Url2 = {};
    devDynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Url2.Url = "https://shop.supervalu.ie/shopping/search/allaisles?q=Purina%20ONE";
    Enabler.setDevDynamicContent(devDynamicContent);

    data.hl1 = dynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Headline1;
    data.shl1 = dynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Subheadline2;
    data.hl2 =  dynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Headline2;
    data.hl3 =  dynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Headline3;
    data.img1 = dynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Image1.Url;
    data.img2 = dynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Image2.Url;
    data.cta =  dynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].CTA;
    data.exitUrl1 =  dynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Url1.Url;
    data.exitUrl2 =  dynamicContent.AdLib__Purina_ONE_3_Week_Challenge_AdLib__Purina_ONE_3_Week_Challenge[0].Url2.Url;

    if(data.hl1.length > 47){
        headline1.style.fontSize = "18px";
    }
}

function decalreExit(){
    Enabler.exitOverride("PurinaOne_3WeekChallenge");
    Enabler.exitOverride("PurinaOne_3WeekChallenge_Tesco");
    Enabler.exitOverride("PurinaOne_3WeekChallenge_SuperValu");
}


