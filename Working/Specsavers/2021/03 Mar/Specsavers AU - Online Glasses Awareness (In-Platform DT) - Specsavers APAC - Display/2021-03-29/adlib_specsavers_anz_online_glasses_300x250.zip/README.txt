This .zip contains two folders: the authoring folder, which contains creative files authored
in tools like Google Web Designer (GWD), Adobe Suite and the published folder, which contains
files generated for publishing and serving.

In Studio, you can add more generated files directly to the creative or delete generated files
from the creative without having to upload another zip. If you download a .zip of the creative
files after any of them were added or removed, Studio will update the contents of the published
folder in the .zip accordingly and this README will list the files that were added or deleted.

Note:
There were no new published assets added to this creative.

There were no published assets deleted from this creative.
